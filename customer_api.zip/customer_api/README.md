# Car & Bike Garage Management System — Customer API

## Windows / VS Code setup

1. Open this folder in VS Code. In the VS Code terminal (PowerShell):

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

2. Open MySQL Workbench and run:

   ```sql
   CREATE DATABASE IF NOT EXISTS garage_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

3. Edit `.env` with your actual MySQL username/password. The supplied setting assumes local MySQL user `root` has no password:

   ```env
   DATABASE_URL=mysql+pymysql://root@localhost:3306/garage_db?charset=utf8mb4
   ```

   If root has a password, use `mysql+pymysql://root:YOUR_PASSWORD@localhost:3306/garage_db?charset=utf8mb4`. URL-encode special password characters (`@` becomes `%40`). A no-password server does not permit every user automatically: MySQL must grant that user access. Keep `.env` private.

4. Start the server from this project root:

   ```powershell
   python -m uvicorn app.main:app --reload
   ```

5. Open http://127.0.0.1:8000/docs and test in this order:

   - POST `/api/v1/customers`: `{ "name": "Ankit Khanderajure", "phone": "9876543210", "email": "ankit@example.com", "address": "Belagavi" }` → 201; note returned `id`.
   - GET `/api/v1/customers` → 200 and a list containing the new customer.
   - GET `/api/v1/customers/1` → 200 (use actual returned ID).
   - PUT `/api/v1/customers/1`: `{ "name": "Ankit Khanderajure", "phone": "9876543210", "email": "ankit@example.com", "address": "Belagavi, Karnataka" }` → 200.
   - DELETE `/api/v1/customers/1` → 200.
   - GET same ID → 404. Reusing a phone/email → 409; invalid phone/email → 422.

